# XRComm 8T8R Hello World

This directory contains an example application demonstrating how to build an out-of-process IQ consumer for the XRComm 8T8R platform using the public `xrcomm_ip_client.h` API.

## Building

```bash
mkdir build && cd build
cmake ..
make
```
The executable `hello_world` will be placed in the `bin/` directory.

## Running

Ensure the XRComm 8T8R platform is running and then execute:
```bash
./bin/hello_world
```
