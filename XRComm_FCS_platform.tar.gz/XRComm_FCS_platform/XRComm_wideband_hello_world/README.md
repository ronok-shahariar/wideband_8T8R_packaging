# XRComm Wideband Hello World

This directory contains two example customer applications for the XRComm Platform:
1. **`hello_world.c`**: Connects via POSIX shared memory to receive IQ data.
2. **`hello_world_fullpkt.c`**: Connects as a DPDK secondary process to receive full zero-copy packets.

## Prerequisites

Before compiling these examples, ensure you have successfully run the main `install.sh` script located in the parent directory. The installer sets up the necessary system includes (`/usr/include/xrcomm-wideband`) which these applications rely on.

You must also have DPDK and `cmake` installed on your system.

## Compilation Instructions

We use CMake to build these examples. The provided `CMakeLists.txt` is configured to place the resulting compiled binaries directly into the local `bin/` directory.

To compile, run the following commands from this directory:

```bash
# 1. Create a build directory
mkdir build
cd build

# 2. Configure the project
cmake ..

# 3. Compile the binaries
make
```

Once compilation is complete, you will find the executable binaries located in `../bin/`:
- `bin/hello_world`
- `bin/hello_world_fullpkt`

## Running the Examples

Ensure the primary `xrcomm-server` service is running before launching the examples.

```bash
# To run the standard IQ consumer:
./bin/hello_world

# To run the DPDK FULL_PACKET consumer (Requires root):
sudo ./bin/hello_world_fullpkt
```
